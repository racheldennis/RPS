﻿/*Rachel Dennis
 * This program lets the user play Rock, Paper, Scissors with the computer. It will let the user play many rounds and keep track of how many times Computer, Human Wins and Ties.
 * The program will also let the user quit to see the results of all the rounds played. Also with every round it will print who wins between User and Computer or if it is a Tie.
 * The user will be able to choose what position they would like to play and when the user clicks computer the program will generate a random position and cannot be changed. The user will click 
 * play again to start a new round. When click start over the results will reset.
 */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp13
{
    public partial class Form1 : Form
    {
        static int count = 1;//creates a integer variable throughout the whole program which represents the count
        static Random r = new Random();//creates a random array throughout the whole program which is used to randomly choose a position for computer
        static int comp = 1;//creates a integer variable for computer's position
        static int human = 1;//creates a integer variable for human's position
        static int Human_Wins = 0;//creates a integer variable for the number of times Human wins
        static int Computer_Wins = 0;//creates a integer variable for the number of times Computer Wins
        static int Ties = 0;//creates a integer variable for the number of times ties occured
        Bitmap img1 = Properties.Resources.Rock;//creates a bitmap variable for rock that stores the rock image from the program's resources
        Bitmap img2 = Properties.Resources.Paper;//creates a bitmap variable for paper that stores the paper image from the program's resources
        Bitmap img3 = Properties.Resources.Scissors;//creates a bitmap variable for scissors that stores the scissors image from the program's resources
        public Form1()
        {
            InitializeComponent();
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            pictureBox1.Visible = true;//pictureBox1 is visible in the form


            if (count == 1)//if the variable count equals 1
            {
                pictureBox1.Image = img1;//pictureBox1 image will equal img1 which is rock
                count++;//count will keep track of the different position you can play
                human = 1;//the variable human will equal 1 which is rock
            }
            else if (count == 2)
            {

                pictureBox1.Image = img2;//pictureBox1 image will equal img2 which is paper
                count++;
                human = 2;//the variable human will equal 2 which is paper

            }
            else
            {
                pictureBox1.Image = img3;//pictureBox2 image will equal img3 which is scissors

                count = 1;//after count will go back to 1
                human = 3;//the variable will equal 3 which is scissors
            }

        }

        private String Compare(int h, int c)//creates a string variable called compare function and has two variable which the value of human and ocmputer goes through
        {
            String result = "";//the string variable result will be blank at first

            if (h == 1 && c == 2)//when the variable h asnd c equals the following numbers
            {
                result = "Human Plays Rock, Computer Plays Paper, Computer Wins";//the result will equal the followin message
                Computer_Wins++;//the variables value increases if the if statement is true (keeps track the number of times Computer Wins)
            }

            else if (h == 1 && c == 3)
            {
                result = "Human Plays Rock, Computer Plays Scissors, Human Wins";
                Human_Wins++;//the variables value increases if the if statement is true (keeps track the number of times Human Wins)
            }

            else if (h == 2 && c == 1)
            {
                result = "Human Plays Paper, Computer Plays Rock, Human Wins";
                Human_Wins++;
            }

            else if (h == 2 && c == 3)
            {
                result = "Human Plays Paper, Computer Plays Scissors, Computer Wins";
                Computer_Wins++;
            }
            
            else if (h == 3 && c == 1)
            {
                result = "Human Plays Scissors, Computer Plays Rock, Computer Wins";
                Computer_Wins++;
            }

            else if (h == 3 && c == 2)
            {
                result = "Human Plays Scissors, Computer Plays Paper, Human Wins";
                Human_Wins++;
            }

            else//if h and c equals any other number
            {
                result = "Tie";//the result will equal tie
                Ties++;//the variables value increases if the if statement is true (keeps track the number of times a Tie occurs)
            }

            return result;//the result of the function returns
        }

        private void Button2_Click(object sender, EventArgs e)
        {
            button3.Enabled = true;//button 3 (Play Again) will be visible in form
            button4.Enabled = true;// button 4 (Quit) will be visible in form
            pictureBox2.Visible = true;// pictureBox2 (Computer Display) will be visible in form
            button1.Enabled = false;// button1 (Choose) will not be enabled and will not let user be able to click the button
            button2.Enabled = false;//button 2 (Computer) will not be enabled and will not let user be able to click the button 



            comp = r.Next(1, 4);//the variable comp continuously equals will randomly equal a number from 1 - 4

            if (comp == 1)//if comp equals the following number
            {
                pictureBox2.Image = img1;//pictureBox2 image will equal img1 which is rock


            }
            else if (comp == 2)
            {
                pictureBox2.Image = img2;//pictureBox2 image will equal img2 which is paper


            }
            else if (comp == 3)
            {
                pictureBox2.Image = img3;//pictureBox2 image will equal img3 which is scissors


            }

            label2.Text = Compare(human, comp);//label2 will equal the result when the variable human and comp goes through the compare function
        }

        private void Button3_Click(object sender, EventArgs e)
        {
            label2.Text = "";//the label2 will be blank
            richTextBox1.Text = "";//the richTextBox1 will equal back to nothing in the form
            button1.Enabled = true;//button1 will be enabled again in the form
            button2.Enabled = true;//button2 will be enabled again in the form
            pictureBox1.Visible = false;//the pictureBox1 will be visible in the form
            pictureBox2.Visible = false;//the pictureBox2 will be visible in the form


        }

        private void Button4_Click(object sender, EventArgs e)
        {
            pictureBox1.Visible = false;//pictureBox1 will be invisible in the form
            pictureBox2.Visible = false;//pictureBox2 will be invisible in the form
            label2.Text = "";//label2 will be blank
            button2.Enabled = false;//button2 will not be enabled and won't let user click the button
            button1.Enabled = false;//button1 will not be enabled and won't let user click the button

            richTextBox1.Text = "Human won " + Human_Wins + " times \n" + "Computer won " + Computer_Wins + " times \n" + Ties + " Ties \n";//the richTextBox1 will print how many times Human won and Computer Won and the number of ties occured

        }

        private void Button5_Click(object sender, EventArgs e)
        {
            label2.Text = "";//label2 will go back to blank
            richTextBox1.Text = "";//the richTextBox1 will go back to blank
            button1.Enabled = true;//button1 will go back to enabled and the user will be able to click the button
            button2.Enabled = true;//button1 will go back to enabled and the user will be able to click the button
            pictureBox1.Visible = false;//pictureBox1 will be invisible and cannot be seen by the user
            pictureBox2.Visible = false;//pictureBox2 will be invisible and cannot be seen by the user
            comp = 1;//comp will equal 1
            human = 1;//human will equal 1
            count = 0;//count will equal to 0
            Human_Wins = 0;//Human Wins will go to 0
            Computer_Wins = 0;//Computer Wins will go to 0
            Ties = 0;//Ties will go to 0
        }
    }
}
